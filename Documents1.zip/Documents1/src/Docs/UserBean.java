package Docs;



public class UserBean {
	private String Batch_ID;
	public String getBatch_ID() {
		return Batch_ID;
	}
	public void setBatch_ID(String batch_ID) {
		Batch_ID = batch_ID;
	}
	private String Student_ID;
	private String HSC;
	
	public String getHSC() {
		return HSC;
	}
	public void setHSC(String hSC) {
		HSC = hSC;
	}
	
	private String Doc1;
	private String Doc2;
	private String Doc3;
	private String Doc4;
	public String getStudent_ID() {
		return Student_ID;
	}
	public void setStudent_ID(String student_ID) {
		Student_ID = student_ID;
	}
	public String getDoc1() {
		return Doc1;
	}
	public void setDoc1(String doc1) {
		Doc1 = doc1;
	}
	public String getDoc2() {
		return Doc2;
	}
	public void setDoc2(String doc2) {
		Doc2 = doc2;
	}
	public String getDoc3() {
		return Doc3;
	}
	public void setDoc3(String doc3) {
		Doc3 = doc3;
	}
	public String getDoc4() {
		return Doc4;
	}
	public void setDoc4(String doc4) {
		Doc4 = doc4;
	}
	
	
	
}
